# Design System Documentation: Clinical Clarity & Editorial Depth

## 1. Overview & Creative North Star
In a high-pressure healthcare environment, digital interfaces must act as a calming, authoritative presence. This design system moves away from the sterile, utilitarian "kiosk" aesthetic toward a **"Clinical Editorial"** North Star. 

The goal is to provide a sense of **Soft Minimalism**—where the UI feels as clean as a modern medical facility but as intuitive and premium as a high-end wellness publication. We break the traditional grid by using generous "breathing room," intentional asymmetry in layout transitions, and a sophisticated layering of whites and blues to guide the patient’s journey without visual noise.

---

## 2. Color Strategy
Our palette is strictly monochromatic in its blue-to-white spectrum, using depth and tone rather than hue to communicate hierarchy.

### The "No-Line" Rule
To achieve a premium, modern feel, **1px solid borders are prohibited for sectioning.** Boundaries must be defined solely through background color shifts or subtle tonal transitions. For example, a card using `surface_container_lowest` (#ffffff) should sit on a background of `surface_container_low` (#f1f4f7) to create a natural, "ink-on-paper" distinction.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers—like stacked sheets of frosted glass.
- **Base Level:** `surface` (#f7fafd)
- **Primary Layout Sections:** `surface_container_low` (#f1f4f7)
- **Interactive Floating Elements:** `surface_container_lowest` (#ffffff)
- **High-Impact Modules:** `surface_container_highest` (#e0e3e6)

### Signature Textures
Avoid flat, "dead" buttons. For primary CTAs, use a subtle linear gradient transitioning from `primary` (#0048b6) to `primary_container` (#2260da) at a 135-degree angle. This adds a "soul" to the component, mimicking the way light hits a physical surface.

---

## 3. Typography
We use a dual-typeface system to balance authority with approachability.

*   **Manrope (Display & Headlines):** Used for large-scale information. It is geometric yet friendly, providing an authoritative "Editorial" feel.
*   **Public Sans (Title, Body, Labels):** A neutral, highly legible sans-serif designed for clarity at any distance or age group.

**Scales:**
- **Display-LG (3.5rem / Manrope):** Vital for totem landing screens (e.g., "Welcome to City Hospital").
- **Headline-MD (1.75rem / Manrope):** For section headers within the flow.
- **Title-MD (1.125rem / Public Sans):** Used for button labels and high-priority list items.
- **Body-LG (1rem / Public Sans):** The standard for all patient instructions.

---

## 4. Elevation & Depth
Depth is not a decoration; it is a way to signal "Touchability" on a totem.

### The Layering Principle
Instead of a shadow for every box, use **Tonal Layering**. Place a `surface_container_lowest` (#ffffff) card on a `surface_container` (#ebeef1) background. The 2-4% shift in brightness is enough for the human eye to perceive a physical lift.

### Ambient Shadows
When an element must "float" (like a notification or a modal), use an **Ambient Shadow**:
- **Color:** `on_surface` (#181c1e) at 6% opacity.
- **Blur:** 32px to 64px.
- **Y-Offset:** 8px.
*This mimics natural light rather than a harsh drop shadow.*

### Glassmorphism
For headers or floating navigation bars, use `surface` (#f7fafd) at 80% opacity with a **20px Backdrop Blur**. This ensures the interface feels integrated with the physical environment, allowing the soft blues of the background to bleed through the edges.

---

## 5. Components

### Buttons (The "Touch-First" Standard)
All buttons use the `xl` (1.5rem) or `full` (9999px) roundedness scale to feel "friendly" and safe.
- **Primary:** Gradient (`primary` to `primary_container`), `on_primary` text. Large padding (24px vertical, 48px horizontal).
- **Secondary:** `surface_container_highest` background with `primary` text. No border.
- **Tertiary:** Transparent background with `primary` text and a trailing `meaningful_icon`.

### Cards & Lists
**Strict Rule:** No divider lines. Separate list items using 16px of vertical white space or by alternating background tones between `surface_container_low` and `surface_container_lowest`.

### Input Fields
To maintain the "No-Line" rule, inputs should be styled as "Plates." Use `surface_container_high` (#e5e8eb) with a `DEFAULT` (0.5rem) corner radius. Upon focus, shift the background to `surface_container_lowest` (#ffffff) and apply a "Ghost Border" using `surface_tint` (#0c56d0) at 20% opacity.

### Navigation Totems
For the totem footer, use a `surface_container_highest` container with high-contrast icons. Each icon must be accompanied by a `label-md` text element to ensure accessibility for elderly patients.

---

## 6. Do's and Don'ts

### Do:
- **Do** use `manrope` for numbers. In a hospital, room numbers and wait times are data—make them beautiful.
- **Do** use the `primary_fixed` (#dae2ff) color for "Information" or "Help" banners; it provides a soft, non-alarming highlight.
- **Do** ensure all touch targets are at least 80px in height for totem accessibility.

### Don't:
- **Don't** use 100% black. Always use `on_surface` (#181c1e) for text to maintain the soft-medical aesthetic.
- **Don't** use `error` (#ba1a1a) for minor warnings. Reserve the red palette strictly for critical errors or emergency stops.
- **Don't** crowd the screen. If a process has more than 4 steps, split it into multiple screens. White space is a tool for reducing patient anxiety.